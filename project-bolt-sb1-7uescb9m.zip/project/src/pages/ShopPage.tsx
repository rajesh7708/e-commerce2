import React, { useState, useEffect } from 'react';
import { Filter, SlidersHorizontal, ChevronDown } from 'lucide-react';
import { products } from '../data/products';
import ProductCard from '../components/shop/ProductCard';
import Button from '../components/ui/Button';
import Breadcrumbs from '../components/ui/Breadcrumbs';
import { Product } from '../types';

const categories = Array.from(new Set(products.map(product => product.category)));
const tags = Array.from(new Set(products.flatMap(product => product.tags)));

const ShopPage: React.FC = () => {
  const [filteredProducts, setFilteredProducts] = useState<Product[]>(products);
  const [activeFilters, setActiveFilters] = useState<{
    categories: string[];
    priceRange: [number, number];
    sortBy: string;
    availability: boolean | null;
  }>({
    categories: [],
    priceRange: [0, 500],
    sortBy: 'featured',
    availability: null,
  });
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  useEffect(() => {
    let result = [...products];

    // Apply category filter
    if (activeFilters.categories.length > 0) {
      result = result.filter(product => 
        activeFilters.categories.includes(product.category)
      );
    }

    // Apply price range filter
    result = result.filter(
      product => {
        const price = product.discountedPrice || product.price;
        return price >= activeFilters.priceRange[0] && price <= activeFilters.priceRange[1];
      }
    );

    // Apply availability filter
    if (activeFilters.availability !== null) {
      result = result.filter(product => product.inStock === activeFilters.availability);
    }

    // Apply sorting
    switch (activeFilters.sortBy) {
      case 'price-low-high':
        result.sort((a, b) => {
          const priceA = a.discountedPrice || a.price;
          const priceB = b.discountedPrice || b.price;
          return priceA - priceB;
        });
        break;
      case 'price-high-low':
        result.sort((a, b) => {
          const priceA = a.discountedPrice || a.price;
          const priceB = b.discountedPrice || b.price;
          return priceB - priceA;
        });
        break;
      case 'newest':
        // For a real app, you'd sort by date
        // This is just a placeholder
        break;
      case 'rating':
        result.sort((a, b) => b.rating - a.rating);
        break;
      default: // featured
        result = result.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
    }

    setFilteredProducts(result);
  }, [activeFilters]);

  const toggleCategory = (category: string) => {
    setActiveFilters(prev => {
      const categories = prev.categories.includes(category)
        ? prev.categories.filter(c => c !== category)
        : [...prev.categories, category];
      return { ...prev, categories };
    });
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setActiveFilters(prev => ({ ...prev, sortBy: e.target.value }));
  };

  const toggleMobileFilter = () => {
    setIsMobileFilterOpen(!isMobileFilterOpen);
  };

  return (
    <div className="bg-white">
      <div className="container mx-auto px-4 py-8">
        <Breadcrumbs 
          items={[{ label: 'Shop', href: '/shop' }]} 
          className="mb-6" 
        />

        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Shop All Products</h1>
          <Button 
            variant="outline" 
            className="md:hidden flex items-center"
            onClick={toggleMobileFilter}
          >
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar / Filters */}
          <div 
            className={`md:w-64 shrink-0 ${
              isMobileFilterOpen 
                ? 'fixed inset-0 bg-white z-40 p-4 overflow-auto'
                : 'hidden md:block'
            }`}
          >
            {isMobileFilterOpen && (
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-medium">Filters</h2>
                <button 
                  onClick={toggleMobileFilter}
                  className="p-2 hover:bg-gray-100 rounded-full"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            )}

            <div className="space-y-6">
              {/* Categories */}
              <div>
                <h3 className="text-sm font-medium text-gray-900 mb-3">Categories</h3>
                <div className="space-y-2">
                  {categories.map(category => (
                    <div key={category} className="flex items-center">
                      <input
                        id={`category-${category}`}
                        type="checkbox"
                        className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        checked={activeFilters.categories.includes(category)}
                        onChange={() => toggleCategory(category)}
                      />
                      <label
                        htmlFor={`category-${category}`}
                        className="ml-3 text-sm text-gray-600 capitalize"
                      >
                        {category}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div>
                <h3 className="text-sm font-medium text-gray-900 mb-3">Price Range</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">
                      ${activeFilters.priceRange[0]}
                    </span>
                    <span className="text-sm text-gray-500">
                      ${activeFilters.priceRange[1]}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="500"
                    step="10"
                    value={activeFilters.priceRange[1]}
                    onChange={(e) => 
                      setActiveFilters(prev => ({
                        ...prev,
                        priceRange: [prev.priceRange[0], parseInt(e.target.value)]
                      }))
                    }
                    className="w-full"
                  />
                </div>
              </div>

              {/* Availability */}
              <div>
                <h3 className="text-sm font-medium text-gray-900 mb-3">Availability</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input
                      id="in-stock"
                      type="radio"
                      name="availability"
                      className="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500"
                      checked={activeFilters.availability === true}
                      onChange={() => 
                        setActiveFilters(prev => ({ ...prev, availability: true }))
                      }
                    />
                    <label htmlFor="in-stock" className="ml-3 text-sm text-gray-600">
                      In Stock
                    </label>
                  </div>
                  <div className="flex items-center">
                    <input
                      id="out-of-stock"
                      type="radio"
                      name="availability"
                      className="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500"
                      checked={activeFilters.availability === false}
                      onChange={() => 
                        setActiveFilters(prev => ({ ...prev, availability: false }))
                      }
                    />
                    <label htmlFor="out-of-stock" className="ml-3 text-sm text-gray-600">
                      Out of Stock
                    </label>
                  </div>
                  <div className="flex items-center">
                    <input
                      id="all-items"
                      type="radio"
                      name="availability"
                      className="h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-500"
                      checked={activeFilters.availability === null}
                      onChange={() => 
                        setActiveFilters(prev => ({ ...prev, availability: null }))
                      }
                    />
                    <label htmlFor="all-items" className="ml-3 text-sm text-gray-600">
                      All Items
                    </label>
                  </div>
                </div>
              </div>

              {/* Clear Filters */}
              <Button
                variant="outline"
                fullWidth
                onClick={() => setActiveFilters({
                  categories: [],
                  priceRange: [0, 500],
                  sortBy: 'featured',
                  availability: null,
                })}
              >
                Clear Filters
              </Button>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Sort Options */}
            <div className="flex justify-between items-center mb-6">
              <p className="text-sm text-gray-500">
                Showing <span className="font-medium">{filteredProducts.length}</span> products
              </p>
              
              <div className="flex items-center">
                <label htmlFor="sort" className="sr-only">Sort by</label>
                <div className="relative">
                  <select
                    id="sort"
                    value={activeFilters.sortBy}
                    onChange={handleSortChange}
                    className="appearance-none pl-3 pr-10 py-2 text-sm border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="featured">Featured</option>
                    <option value="price-low-high">Price: Low to High</option>
                    <option value="price-high-low">Price: High to Low</option>
                    <option value="newest">Newest</option>
                    <option value="rating">Best Rating</option>
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-500">
                    <ChevronDown className="h-4 w-4" />
                  </div>
                </div>
              </div>
            </div>

            {/* Products Grid */}
            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-10">
                {filteredProducts.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <SlidersHorizontal className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No products found</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Try adjusting your filters to find what you're looking for.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShopPage;