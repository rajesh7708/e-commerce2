import { Category } from '../types';

export const categories: Category[] = [
  {
    id: 'electronics',
    name: 'Electronics',
    image: 'https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'Latest gadgets and tech accessories'
  },
  {
    id: 'home',
    name: 'Home & Decor',
    image: 'https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'Beautiful pieces for your living space'
  },
  {
    id: 'kitchen',
    name: 'Kitchen',
    image: 'https://images.pexels.com/photos/1080696/pexels-photo-1080696.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'Cookware, tools, and dining essentials'
  },
  {
    id: 'accessories',
    name: 'Accessories',
    image: 'https://images.pexels.com/photos/934063/pexels-photo-934063.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'Bags, watches, and personal items'
  },
  {
    id: 'health',
    name: 'Health & Wellness',
    image: 'https://images.pexels.com/photos/3735644/pexels-photo-3735644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'Products for a healthier lifestyle'
  }
];