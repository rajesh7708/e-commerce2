import { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Minimalist Desk Lamp',
    description: 'A sleek, adjustable desk lamp with warm lighting perfect for your workspace. Features touch-sensitive controls and multiple brightness settings.',
    price: 89.99,
    discountedPrice: 69.99,
    currency: 'USD',
    images: [
      'https://images.pexels.com/photos/1112598/pexels-photo-1112598.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/3637740/pexels-photo-3637740.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'home',
    tags: ['lighting', 'desk', 'office'],
    featured: true,
    inStock: true,
    rating: 4.7,
    reviews: 128
  },
  {
    id: '2',
    name: 'Wireless Headphones',
    description: 'Premium noise-cancelling headphones with 30-hour battery life. Includes fast charging and crystal clear audio quality for immersive listening.',
    price: 249.99,
    currency: 'USD',
    images: [
      'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/577769/pexels-photo-577769.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'electronics',
    tags: ['audio', 'wireless', 'headphones'],
    featured: true,
    inStock: true,
    rating: 4.9,
    reviews: 246
  },
  {
    id: '3',
    name: 'Ceramic Pour-Over Coffee Set',
    description: 'Handcrafted ceramic pour-over coffee maker with matching mug. The perfect way to brew a single cup of artisanal coffee with precision and style.',
    price: 64.99,
    currency: 'USD',
    images: [
      'https://images.pexels.com/photos/3020919/pexels-photo-3020919.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'kitchen',
    tags: ['coffee', 'ceramic', 'brewing'],
    featured: false,
    inStock: true,
    rating: 4.5,
    reviews: 87
  },
  {
    id: '4',
    name: 'Smart Watch Series 5',
    description: 'Track your fitness, receive notifications, and more with this water-resistant smart watch. Features heart rate monitoring and GPS.',
    price: 299.99,
    discountedPrice: 249.99,
    currency: 'USD',
    images: [
      'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1682821/pexels-photo-1682821.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'electronics',
    tags: ['wearable', 'fitness', 'smart watch'],
    featured: true,
    inStock: true,
    rating: 4.6,
    reviews: 189
  },
  {
    id: '5',
    name: 'Leather Weekender Bag',
    description: 'Premium full-grain leather weekender with ample space for all your travel essentials. Features durable hardware and a detachable shoulder strap.',
    price: 199.99,
    currency: 'USD',
    images: [
      'https://images.pexels.com/photos/2081199/pexels-photo-2081199.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'accessories',
    tags: ['leather', 'travel', 'bag'],
    featured: false,
    inStock: true,
    rating: 4.8,
    reviews: 76
  },
  {
    id: '6',
    name: 'Minimalist Wall Clock',
    description: 'Scandinavian-inspired wall clock with a clean design and silent movement. A perfect accent piece for any room in your home.',
    price: 59.99,
    currency: 'USD',
    images: [
      'https://images.pexels.com/photos/1095601/pexels-photo-1095601.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/745365/pexels-photo-745365.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'home',
    tags: ['clock', 'decor', 'minimalist'],
    featured: false,
    inStock: true,
    rating: 4.4,
    reviews: 52
  },
  {
    id: '7',
    name: 'Plant-Based Protein Powder',
    description: 'Organic plant-based protein powder with 25g of protein per serving. No artificial flavors, sweeteners, or preservatives.',
    price: 49.99,
    currency: 'USD',
    images: [
      'https://images.pexels.com/photos/5945559/pexels-photo-5945559.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/8844388/pexels-photo-8844388.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'health',
    tags: ['protein', 'supplement', 'fitness'],
    featured: false,
    inStock: true,
    rating: 4.3,
    reviews: 104
  },
  {
    id: '8',
    name: 'Ceramic Plant Pot Set',
    description: 'Set of 3 ceramic plant pots in varying sizes with bamboo trays. Perfect for succulents, herbs, or small houseplants.',
    price: 39.99,
    currency: 'USD',
    images: [
      'https://images.pexels.com/photos/1084199/pexels-photo-1084199.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1701110/pexels-photo-1701110.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'home',
    tags: ['plants', 'decor', 'ceramic'],
    featured: true,
    inStock: true,
    rating: 4.5,
    reviews: 68
  }
];

export const getProductById = (id: string): Product | undefined => {
  return products.find(product => product.id === id);
};

export const getFeaturedProducts = (): Product[] => {
  return products.filter(product => product.featured);
};

export const getProductsByCategory = (category: string): Product[] => {
  return products.filter(product => product.category === category);
};