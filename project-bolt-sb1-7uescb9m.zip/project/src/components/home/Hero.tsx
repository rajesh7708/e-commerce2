import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import Button from '../ui/Button';

const Hero: React.FC = () => {
  return (
    <div className="relative bg-gray-50">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-white to-gray-50" />
      
      <div className="container mx-auto px-4 py-24 md:py-32 lg:py-40 relative">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="max-w-xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
              Modern Essentials for 
              <span className="text-blue-600"> Everyday Living</span>
            </h1>
            <p className="mt-6 text-lg text-gray-600">
              Discover thoughtfully designed products that enhance your lifestyle. Quality craftsmanship, sustainable materials, and timeless design.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-4">
              <Button variant="primary" size="lg" as={Link} to="/shop">
                Shop Collection
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button variant="outline" size="lg" as={Link} to="/categories">
                Browse Categories
              </Button>
            </div>
            <div className="mt-10 flex items-center space-x-6">
              <div className="flex -space-x-2">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="inline-block h-8 w-8 rounded-full bg-gray-200 border-2 border-white overflow-hidden">
                    <img
                      src={`https://i.pravatar.cc/100?img=${i + 10}`}
                      alt={`Customer ${i}`}
                      className="h-full w-full object-cover"
                    />
                  </div>
                ))}
              </div>
              <div>
                <div className="flex items-center">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <svg
                      key={star}
                      className="h-4 w-4 text-yellow-400"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path
                        fillRule="evenodd"
                        d="M10 15.585l-7.071 3.821 1.357-7.909L.572 7.038l7.931-1.15L10 0l2.497 5.887 7.931 1.15-5.714 5.46 1.357 7.909z"
                        clipRule="evenodd"
                      />
                    </svg>
                  ))}
                </div>
                <p className="text-sm text-gray-500">
                  <span className="font-medium">4.9</span> from over{" "}
                  <span className="font-medium">500</span> reviews
                </p>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="aspect-square rounded-2xl overflow-hidden shadow-2xl bg-white p-4">
              <img
                src="https://images.pexels.com/photos/4352247/pexels-photo-4352247.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="Featured product"
                className="w-full h-full object-cover rounded-xl"
              />
              <div className="absolute bottom-8 left-8 right-8 bg-white/90 backdrop-blur-sm p-6 rounded-xl">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Modern Design Collection</h3>
                    <p className="text-gray-600 mt-1">Starting at $49.99</p>
                  </div>
                  <Link 
                    to="/shop" 
                    className="bg-blue-600 rounded-full p-2 text-white hover:bg-blue-700 transition-colors"
                  >
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -bottom-6 -left-6 h-24 w-24 bg-yellow-400 rounded-full opacity-20" />
            <div className="absolute -top-6 -right-6 h-32 w-32 bg-blue-400 rounded-full opacity-20" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;