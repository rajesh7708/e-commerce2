import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, Heart } from 'lucide-react';
import { Product } from '../../types';
import Badge from '../ui/Badge';
import { useCart } from '../../context/CartContext';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addItem } = useCart();
  const hasDiscount = product.discountedPrice !== undefined;
  const discountPercentage = hasDiscount
    ? Math.round(((product.price - product.discountedPrice!) / product.price) * 100)
    : 0;

  return (
    <div className="group relative">
      {/* Product Image */}
      <div className="aspect-square w-full overflow-hidden rounded-lg bg-gray-100">
        <img
          src={product.images[0]}
          alt={product.name}
          className="h-full w-full object-cover object-center group-hover:opacity-90 transition-opacity duration-300"
        />
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-all duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
          <div className="flex space-x-2">
            <button 
              onClick={(e) => {
                e.preventDefault();
                addItem(product);
              }}
              className="bg-white p-2 rounded-full shadow-md hover:bg-blue-50 transition-colors"
              aria-label="Add to cart"
            >
              <ShoppingCart className="h-5 w-5 text-blue-600" />
            </button>
            <button 
              className="bg-white p-2 rounded-full shadow-md hover:bg-blue-50 transition-colors"
              aria-label="Add to wishlist"
            >
              <Heart className="h-5 w-5 text-blue-600" />
            </button>
          </div>
        </div>
      </div>

      {/* Discount Badge */}
      {hasDiscount && (
        <div className="absolute top-2 left-2">
          <Badge variant="error">-{discountPercentage}%</Badge>
        </div>
      )}

      {/* Featured Badge */}
      {product.featured && !hasDiscount && (
        <div className="absolute top-2 left-2">
          <Badge variant="primary">Featured</Badge>
        </div>
      )}

      {/* Product Details */}
      <div className="mt-4 flex justify-between">
        <div>
          <h3 className="text-sm font-medium text-gray-900">
            <Link to={`/product/${product.id}`}>
              <span aria-hidden="true" className="absolute inset-0" />
              {product.name}
            </Link>
          </h3>
          <p className="mt-1 text-sm text-gray-500 capitalize">{product.category}</p>
        </div>
        <div className="text-sm font-medium text-right">
          {hasDiscount ? (
            <div>
              <span className="text-gray-500 line-through">${product.price.toFixed(2)}</span>
              <span className="ml-2 text-red-600">${product.discountedPrice!.toFixed(2)}</span>
            </div>
          ) : (
            <span className="text-gray-900">${product.price.toFixed(2)}</span>
          )}
        </div>
      </div>

      {/* Rating */}
      <div className="mt-1 flex items-center">
        <div className="flex items-center">
          {[...Array(5)].map((_, i) => (
            <svg
              key={i}
              className={`h-3 w-3 ${
                i < Math.floor(product.rating) ? 'text-yellow-400' : 'text-gray-300'
              }`}
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fillRule="evenodd"
                d="M10 15.585l-7.071 3.821 1.357-7.909L.572 7.038l7.931-1.15L10 0l2.497 5.887 7.931 1.15-5.714 5.46 1.357 7.909z"
                clipRule="evenodd"
              />
            </svg>
          ))}
        </div>
        <p className="ml-1 text-xs text-gray-500">({product.reviews})</p>
      </div>
    </div>
  );
};

export default ProductCard;