import React from 'react';
import { X, ShoppingCart, Plus, Minus, Trash2 } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import Button from '../ui/Button';

const Cart: React.FC = () => {
  const { 
    state, 
    toggleCart, 
    updateQuantity, 
    removeItem, 
    clearCart, 
    totalItems, 
    totalPrice 
  } = useCart();

  return (
    <div
      className={`fixed inset-0 bg-black bg-opacity-50 z-50 transition-opacity ${
        state.isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
      }`}
    >
      <div 
        className={`absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-xl transform transition-transform duration-300 ${
          state.isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="px-4 py-4 border-b border-gray-200 flex items-center justify-between">
            <div className="flex items-center">
              <ShoppingCart className="h-5 w-5 text-blue-600 mr-2" />
              <h2 className="text-lg font-medium">Shopping Cart ({totalItems})</h2>
            </div>
            <button
              onClick={toggleCart}
              className="p-2 rounded-full hover:bg-gray-100 transition-colors"
              aria-label="Close cart"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto py-4 px-4">
            {state.items.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full">
                <ShoppingCart className="h-16 w-16 text-gray-300 mb-4" />
                <p className="text-gray-500 text-center">
                  Your cart is empty.
                </p>
                <Button
                  variant="primary"
                  className="mt-4"
                  onClick={toggleCart}
                >
                  Continue Shopping
                </Button>
              </div>
            ) : (
              <ul className="divide-y divide-gray-200">
                {state.items.map((item) => (
                  <li key={item.product.id} className="py-4">
                    <div className="flex items-center">
                      {/* Product Image */}
                      <div className="h-16 w-16 rounded-md bg-gray-100 overflow-hidden">
                        <img
                          src={item.product.images[0]}
                          alt={item.product.name}
                          className="h-full w-full object-cover object-center"
                        />
                      </div>

                      {/* Product Details */}
                      <div className="ml-4 flex-1">
                        <h3 className="text-sm font-medium text-gray-900">
                          {item.product.name}
                        </h3>
                        <p className="text-sm text-gray-500 capitalize">{item.product.category}</p>
                        <div className="mt-1 flex items-center justify-between">
                          <p className="text-sm font-medium text-gray-900">
                            ${(item.product.discountedPrice || item.product.price).toFixed(2)}
                          </p>
                          <div className="flex items-center border rounded-md">
                            <button
                              onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                              className="p-1 hover:bg-gray-100"
                              aria-label="Decrease quantity"
                            >
                              <Minus className="h-4 w-4" />
                            </button>
                            <span className="px-2 text-sm">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                              className="p-1 hover:bg-gray-100"
                              aria-label="Increase quantity"
                            >
                              <Plus className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Remove Button */}
                      <button
                        onClick={() => removeItem(item.product.id)}
                        className="ml-4 p-1 text-gray-400 hover:text-red-500 transition-colors"
                        aria-label="Remove item"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Footer */}
          {state.items.length > 0 && (
            <div className="border-t border-gray-200 px-4 py-4">
              <div className="flex justify-between mb-2">
                <span className="text-sm text-gray-500">Subtotal</span>
                <span className="text-sm font-medium">${totalPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between mb-4">
                <span className="text-sm text-gray-500">Shipping</span>
                <span className="text-sm font-medium">Calculated at checkout</span>
              </div>
              <div className="flex justify-between mb-4">
                <span className="text-base font-medium">Total</span>
                <span className="text-base font-medium">${totalPrice.toFixed(2)}</span>
              </div>
              <div className="space-y-2">
                <Button
                  variant="primary"
                  fullWidth
                  onClick={() => {
                    // Implement checkout logic
                  }}
                >
                  Proceed to Checkout
                </Button>
                <Button
                  variant="outline"
                  fullWidth
                  onClick={clearCart}
                >
                  Clear Cart
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Cart;