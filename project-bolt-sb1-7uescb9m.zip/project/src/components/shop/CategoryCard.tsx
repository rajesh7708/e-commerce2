import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Category } from '../../types';

interface CategoryCardProps {
  category: Category;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category }) => {
  return (
    <Link to={`/category/${category.id}`} className="group relative overflow-hidden rounded-lg">
      <div className="aspect-square md:aspect-[3/2] lg:aspect-[2/1] overflow-hidden bg-gray-100">
        <img
          src={category.image}
          alt={category.name}
          className="h-full w-full object-cover object-center transform group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex flex-col justify-end p-6">
          <h3 className="text-xl font-semibold text-white mb-1">{category.name}</h3>
          <p className="text-sm text-white/80 mb-2">{category.description}</p>
          <div className="flex items-center text-white text-sm opacity-80 group-hover:opacity-100 transition-opacity">
            <span>Explore</span>
            <ArrowRight className="ml-1 h-4 w-4 transform group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
      </div>
    </Link>
  );
};

export default CategoryCard;